#warning redirecting incorrect #include <sys/signal.h> to <signal.h>
#include <signal.h>
