#undef __WORDSIZE
#define __WORDSIZE 64
